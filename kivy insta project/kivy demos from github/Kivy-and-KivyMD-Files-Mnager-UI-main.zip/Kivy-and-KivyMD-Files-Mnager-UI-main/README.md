# Kivy and KivyMD-Files-Manager-UI

A nice clear Files Manager UI contains custom colorful icons, custom canvas, smooth cards with rounded corners and the dark mode with Blue Gray color make the app user-friendly.


## requirements

`pip install kivy`  
`pip install kivymd`  
  
  
  
[watch on YouTube ](https://youtu.be/PHoLyrxL_bU)


![Screenshot](AppScreenshot.jpg)

 
  
   
    

![Alt Text](app-gif.gif)
